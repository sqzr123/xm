<template>
  <!--      轮播图-->
  <div class="carousel-map">
    <el-carousel
      :interval="3000"
      @change="changeImg"
      style="width: 100%"
      arrow="always"
      height="580px"
    >
      <el-carousel-item v-for="(item, index) in bannerList" :key="index">
        <el-image
          :class="className"
          style="width: 100%; height: 100%"
          :src="item"
          fit="cover"
        ></el-image>
      </el-carousel-item>
    </el-carousel>
  </div>
</template>
<script>
export default {

  name: 'home',
  data () {
    const img_1 = require('@/assets/images/lunbo_1.jpg')
    const img_2 = require('@/assets/images/lunbo_2.jpg')
    const img_3 = require('@/assets/images/lunbo_3.jpg')
    const img_4 = require('@/assets/images/lunbo_4.jpg')
    return {
      bannerList: [img_1, img_2, img_3, img_4], // 轮播图地址 这块写你们的轮播图数组即可
      className: ''// 轮播图名字
    }
  },
  mounted () {
    this.className = 'lun-img'
    setTimeout(() => {
      this.className = 'lun-img-two'
    }, 300)
  },
  methods: {
    // 轮播图切换
    changeImg (e) {
      // console.log(e, "当前下标");
      this.className = 'lun-img'
      setTimeout(() => {
        this.className = 'lun-img-two'
      }, 300)
    }
  }
}
</script>

<style scoped lang='less'>
.carousel-map {
  width: 100%;
  height: 580px;
  overflow: hidden;
  //  .lun-img {
  //     transform: scale(1.5);//将图片放大
  //   }

  .lun-img-two {
    transition: all 3s; //恢复正常过渡的时间
    transform: scale(1); //将图片恢复正常
  }
  .el-carousel__item.is-animating {
    transition: all 0.6s;
  }
}
// 修改轮播图圆点样式
/deep/.el-carousel__button {
  width: 12px;
  height: 10px;
  opacity: 0.7;
  background: #ffffff;
  border-radius: 5px;
}
// 修改轮播图圆点选中样式
/deep/.el-carousel__indicator.is-active button {
  width: 18px;
  height: 10px;
  background: red;
  border-radius: 5px;
}
// 修改轮播图圆点位置
/deep/.el-carousel__indicators--horizontal {
  bottom: 215px;
  left: 50%;
  transform: translateX(-50%);
}
/deep/.el-carousel__arrow {
  width: 40px;
  height: 70px;
  background: rgba(0, 0, 0, .3);
  border-radius: 2px;
  font-size: 24px;
}
</style>
