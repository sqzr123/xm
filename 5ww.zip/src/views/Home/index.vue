<template>
  <div>
    <!-- 轮播图 -->
    <Swiper></Swiper>
    <!-- 登录 -->
    <Login></Login>
    <div class="w">
      <!-- 精品推荐 -->
      <div class="center">
        <!-- 推荐轮播图 -->
        <div class="left">
          <div class="top">
            <RotationsRecommended></RotationsRecommended>
          </div>
          <div class="bottom"></div>
        </div>
        <!--  新服列表 -->
        <div class="right"></div>
      </div>
      <!-- 热门推荐 -->
      <div class="center">热门推荐</div>
    </div>
  </div>
</template>

<script>
import Swiper from '@/components/Swiper.vue'
import RotationsRecommended from '@/components/RotationsRecommended.vue'
import Login from '@/views/Login'
export default {
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: { Swiper, Login, RotationsRecommended }
}
</script>

<style scoped lang='less'>
.w {
  width: 1920px;
  margin: 0 auto;
}
.center {
  padding: 0 240px;
}
</style>
